export const createArray = length => [...Array(length)];
