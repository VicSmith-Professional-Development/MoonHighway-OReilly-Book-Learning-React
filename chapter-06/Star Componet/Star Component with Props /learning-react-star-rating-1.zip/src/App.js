import React from "react";
import StartRating from "./StarRating";

export default function App() {
  return <StartRating totalStars={1000} />;
}
